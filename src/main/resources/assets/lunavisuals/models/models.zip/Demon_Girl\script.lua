PirOdd = require("PirateOddities/PirMain")
local physBone = require('physBoneAPI_MODIFIED')

-- deepcopy, aquired from figura discord #code-snippets by manuel_2867
function deepcopy(part, name)
    local copy = part:copy(part:getName() .. (name or "_copy"))
    for _, child in ipairs(part:getChildren()) do
        copy:removeChild(child)
        deepcopy(child):moveTo(copy)
    end
    return copy
end

-- small check
if not textures["texture"] then
	if textures["demongirl.texture"] then
		-- texture likely is now saved internally in the BBmodel which will cause problems
		error("Main texture is not being refrenced correctly!\n\nYou need to either save the model's texture into the avatar folder, or replace the texture with the version found in the avatar folder")
	end
	-- main texture is completely missing?
	error("Could not find main texture (was it removed from the model?)")
end

-- globals
MODELPATH = models.demongirl
ANIMPATH = animations.demongirl

-- states
local poseState = false
local stanceState = false
local prevShowHat = false
local wasSleeping = false

-- model setup
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.HELMET:setVisible(true)

MODELPATH.root.UpperBody.Body.Tail.Tail2.Tail3.Tail4.tip:setPrimaryRenderType("CUTOUT_CULL")
MODELPATH.Skull.PBody.PTail:setPrimaryRenderType("CUTOUT_CULL")

MODELPATH.root.UpperBody.Body.Wings:setPrimaryRenderType("CUTOUT_CULL")

deepcopy(MODELPATH.root.UpperBody.Head):setParentType("PORTRAIT"):moveTo(MODELPATH):setPos(0,-26,0)
--deepcopy(MODELPATH.root.UpperBody.Head):setParentType("SKULL"):moveTo(MODELPATH):setPos(0,-26,0)

MODELPATH.root.UpperBody.Teddy:setVisible(false):setPrimaryRenderType("CUTOUT_CULL")

-- libary calls for pysics
local bodySmoothRot = PirOdd.SmoothRot.new(MODELPATH.root.UpperBody)
bodySmoothRot.crouchBody = vec(0,1,0)
bodySmoothRot.crouchHead = vec(0,-8,0)

local ears = PirOdd.Ears.new(MODELPATH.root.UpperBody.Head.LeftEar, MODELPATH.root.UpperBody.Head.RightEar, -30,25)
ears.flickChance = -1
ears.velIntensity = 5
ears.horizontal = true

ears.minYaw = -10
ears.maxYaw = 10
		
ears.minPitch = -15
ears.maxPitch = 15

local eyes = PirOdd.Eyes.new(MODELPATH.root.UpperBody.Head.Eyes.LEye, MODELPATH.root.UpperBody.Head.Eyes.REye, ANIMPATH.blink, ANIMPATH.closeeyes)

local breasts = PirOdd.BouncyPart.new(MODELPATH.root.UpperBody.Body.UpperTorso.Breasts, vec(0,0.15,0), vec(1.8,2,1))

breasts.rotBounce.min = vec(-30,-20,-10)
breasts.rotBounce.max = vec(30,15,10)

breasts.posBounce.min = vec(0,-0.5,0)
breasts.posBounce.max = vec(0,0.5,0)

breasts.breastStuff = true

breasts.enabled = true -- set this to false to disable breast physics

local tail = PirOdd.Tail.new(MODELPATH.root.UpperBody.Body.Tail,nil,nil,1.5,3)

tail.idleXIntensity = 20
tail.idleYIntensity = 10

tail.segmentDecay = 12
tail.segmentOffset = 4

local FrontHairBounce = PirOdd.BounceValue.new(0.05, 0.2, vec(0,-30,-30), vec(30,30,30), 2, 0.2)

Wings = PirOdd.Wings.new(
	{
		{part = MODELPATH.root.UpperBody.Body.Wings.LeftWingAnchor.LeftWing1, multi = 1,},
		{part = MODELPATH.root.UpperBody.Body.Wings.RightWingAnchor.RightWing1, multi = -1,},
	}
)

Wings.enabled = false

function events.tick()
	if player:isLoaded() then
		local localVel = vec(PirOdd.localVel.z*2,0,-PirOdd.localVel.x)*5
		
		local frontVel = vec(bodySmoothRot.instantHeadVel.x,0,bodySmoothRot.instantHeadVel.y+PirOdd.bodyRotDelta*0.2)*0.2
		
		-- hair physics
		FrontHairBounce:updateTick(localVel+frontVel, vec((bodySmoothRot.instantHeadRot.x+bodySmoothRot.instantBodyRot.x)*-0.75,0,bodySmoothRot.instantBodyRot.z+PirOdd.bodyRotDelta*0.3))
		
		-- hat and horn hiding
		local showHat = (OutfitMultiAction.state == 4 or OutfitMultiAction.state == 5) and (player:getItem(6).id == "minecraft:air" or HideHelmetAction.state)
		
		if prevShowHat ~= showHat then
			MODELPATH.root.UpperBody.Head.Hats:setVisible(showHat)
			MODELPATH.root.UpperBody.Head.LeftHorn.LeftHorn2:setVisible(not showHat)
			MODELPATH.root.UpperBody.Head.RightHorn.RightHorn2:setVisible(not showHat)
			prevShowHat = showHat
		end
		
		-- sleep
		
		if player:getPose() == "SLEEPING" ~= wasSleeping then
			wasSleeping = player:getPose() == "SLEEPING"
			
			ANIMPATH.sleep:setPlaying(wasSleeping)
			MODELPATH.root.UpperBody.Teddy:setVisible(wasSleeping)
		end
	end
end

function events.entity_init()
	-- buncha physbone stuff
	physBone:setPreset("bangs",0.1,8,nil,0.05,nil)
	
	--leftBang = MODELPATH.root.UpperBody.Head.Hair.LeftBang:newPhysBone("bangs"):setNodeEnd(3):setRotMod(leftBangRot):setBounce(0):setAngleLimits({-30,30,-5,20}):setSimSpeed(1):setLength(4)
	--rightBang = MODELPATH.root.UpperBody.Head.Hair.RightBang:newPhysBone("bangs"):setNodeEnd(3):setRotMod(rightBangRot):setBounce(0):setAngleLimits({-30,30,-5,20}):setSimSpeed(1):setLength(4)
	
	ponyTailRot = MODELPATH.root.UpperBody.Head.Hair.Ponytail:getRot()
	
	ponyTail = MODELPATH.root.UpperBody.Head.Hair.Ponytail:newPhysBone("bangs"):setNodeEnd(3):setRotMod(ponyTailRot):setBounce(0):setAngleLimits({-60,60,-90,5}):setSimSpeed(1)
	
	ponyTail2Rot = MODELPATH.root.UpperBody.Head.Hair.Ponytail.Ponytail2.Ponytail3:getRot()
	
	ponyTail2 = MODELPATH.root.UpperBody.Head.Hair.Ponytail.Ponytail2.Ponytail3:newPhysBone("bangs"):setNodeEnd(3):setRotMod(ponyTail2Rot):setSimSpeed(1)
end

function events.item_render(item, context)
	-- replace sword/trident  with new trident
	if not HideTridentAction.state then
		if item.id:find("sword") or item.id:find("trident") then
			if context:find("FIRST_PERSON") then
				MODELPATH.ItemTrident:setScale(0.75)
			else
				MODELPATH.ItemTrident:setScale(1)
			end
			return MODELPATH.ItemTrident
		end
	end
end

function events.render(delta, context)
	MODELPATH.root.UpperBody.Head:setVisible(not (renderer:isFirstPerson() and (context == "OTHER" or context == "RENDER")))
	
	MODELPATH.root.UpperBody.Head.Hair.FrontHair:setOffsetRot(FrontHairBounce:updateRender(delta,delta))
end