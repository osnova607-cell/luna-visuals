local actionHelper = require("actionHelper")
require("script")

-- actions
local page = action_wheel:newPage()
action_wheel:setPage(page)

function HideHelmet(state, playSound)
	vanilla_model.HELMET:setVisible(not state)
	
	if playSound and player:isLoaded() then
		-- taken and heavily modified from FiguraMC Discord server #code-snippets from @dopadream and @auriafoxgirl
		local item = player:getItem(6).id
		local material = item:match('^[^:]+:([^_]+)')
		
		if material then
			local sound = 'item.armor.equip_' .. material
			
			-- edge cases
			if sound == "chainmail" then
				sound = "item.armor.equip_chain"
			elseif sound == "golden" then
				sound = "item.armor.equip_gold"
			end
			
			-- play
			if sound then
				sounds[sound]:pos(player:getPos()):volume(0.5):play()
			end
		end
	end
end

HideHelmetAction = actionHelper.toggle(page, "Hide Helmet", HideHelmet)
	
function hideTrident(state)
	if player:isLoaded() then
		sounds["item.armor.equip_chain"]:pos(player:getPos()):volume(0.5):subtitle("Trident Equips"):play()
	end
end
	
HideTridentAction = actionHelper.toggle(page, "Hide Trident", hideTrident)

local poseAction = actionHelper.pose(page, "Pose", ANIMPATH.pose)

function teddyPose(state)
	MODELPATH.root.UpperBody.Teddy:setVisible(state)
end

local teddyPoseAction = actionHelper.pose(page, "Teddy Bear Pose", ANIMPATH.succubuspose, teddyPose)

local stanceAction = actionHelper.pose(page, "Stance", ANIMPATH.weaponstance)

local sitAction = actionHelper.pose(page, "Sit", ANIMPATH.sit)

-- outfit change action

-- to add a new outfit, you must:
--		1. make a new texture and add it to the blockbench model
--		2. add the texture to the end of the outfits array
--		3. increase the number in the OutfitMultiAction definition
--		4. (optional) add a name for the outfit to the end of the names array

local outfits = {
	textures["texture"],
	textures["texture_swim"],
	textures["texture_suit"],
	textures["texture_pj"],
	textures["texture_santa"],
	
	-- add additional outfit textures here
	-- eg: textures[TEXTURE_PATH],
}

function outfitChange(state, playSound)
	-- apply outfit texture
	MODELPATH.root:setPrimaryTexture("CUSTOM", outfits[state])
	
	-- re-apply wing textures
	MODELPATH.root.UpperBody.Body.Wings:setPrimaryTexture("CUSTOM", textures["wings"])
	
	-- re-apply teddy textures
	MODELPATH.root.UpperBody.Teddy:setPrimaryTexture("CUSTOM", textures["texture_pj"])
	MODELPATH.root.UpperBody.Teddy.PBody2.PTail4:setPrimaryTexture("CUSTOM", textures["plushie"])
	
	-- show/hide cubes
	MODELPATH.root.UpperBody.Body.UpperTorso.Breasts.santa:setVisible(state == 5)
	MODELPATH.root.UpperBody.Body.UpperTorso.MidTorso.santa:setVisible(state == 5)
	
	if player:isLoaded() and playSound then
		sounds["minecraft:item.armor.equip_leather"]:pos(player:getPos()):subtitle("Outfit Shuffles"):pitch(0.7):volume(2):play()
	end
end

-- increase this number (default 4) to the total amount of outfits:
-- it represents the maximum number the state can reach, and adding new outfits increases the possible states
OutfitMultiAction = actionHelper.multi(page, "Outfit", 5, outfitChange,
{	-- outfit names
	"Default",
	"Swimwear",
	"Formal Suit",
	"Pajamas",
	"Santa",
	
	-- add aditional outfit names here
	-- eg: "Outfit Name"
})

function showWings(state, manual)
	Wings.enabled = state
	MODELPATH.root.UpperBody.Body.Wings:setVisible(state)
	
	if player:isLoaded() and manual then
		sounds["entity.phantom.flap"]:pos(player:getPos()):subtitle("Wings Flap"):pitch(1.5):volume(2):play()
	end
end

ToggleWingsAction = actionHelper.toggle(page, "Wings", showWings)

-- sync
function pings.sync(hideHelmetState, hideTridentState, outfitState, wingState)
	HideHelmet(hideHelmetState)
	HideTridentAction.state = hideTridentState
	OutfitMultiAction.state = outfitState
	outfitChange(outfitState)
	showWings(wingState)
end

if host:isHost() then
	HideHelmetAction.action
		:setTexture(textures["icons.helmet"]):setTitle("Hide Helmet")	
		:setToggleTexture(textures["icons.helmet_disable"]):setToggleTitle("Show Helmet")
	HideTridentAction.action
		:setTexture(textures["icons.trident_i"]):setTitle("Hide Trident")	
		:setToggleTexture(textures["icons.trident_disable"]):setToggleTitle("Show Trident")
	poseAction.action:setTexture(textures["icons.pose"])
	teddyPoseAction.action:setTexture(textures["icons.pose"])
	sitAction.action:setTexture(textures["icons.sit_down"])
	stanceAction.action:setTexture(textures["icons.sword"])
	OutfitMultiAction.action:setTexture(textures["icons.shirt"])
	ToggleWingsAction.action:setTexture(textures["icons.wing"])
	
	-- periodic sync
	function events.tick()
		if world:getTime()%100 == 0 then
			pings.sync(HideHelmetAction.state, HideTridentAction.state, OutfitMultiAction.state, ToggleWingsAction.state)
		end
	end
end